package fam100

// T return text based on the language
// TODO:
func T(s string) string {
	return s
}
